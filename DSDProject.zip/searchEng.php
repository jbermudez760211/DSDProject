
<!DOCTYPE html>
<html>
<head>
	<meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link href="css/style.css" rel="stylesheet">
     <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.0.0-beta1/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-giJF6kkoqNQ00vy+HMDP7azOuL0xtbfIcaT9wjKHr8RbDVddVHyTfAAsrekwKmP1" crossorigin="anonymous">
	<title> Search by Engine Number</title>
</head>
<body>
	<h1> Search by Engine Number</h1>
<table class="table">

       <div class="container mt-5">
                    <form action="filterEng.php" method="POST">
                      <br> Engine Number </br>
                      <input type="text" c class="form-control mb-3" name="NoEngine" class="col-md-8"  placeholder="">

                <input type="submit" class="btn btn-primary" value="Filter.....">
       </form>

      </table> 
</body>
</html>